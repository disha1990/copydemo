﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using Microsoft.Office.Interop.Excel;
using System.Reflection;
namespace WindowsApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
      
        private void button1_Click(object sender, EventArgs e)
        {
            Excel.Application excelApplicationClass = new Microsoft.Office.Interop.Excel.Application();
            Excel.Workbook destWorkbook = null;
            Excel.Workbook curWorkBook = null;
            Excel.Worksheet workSheet = null;
            Excel.Worksheet newWorksheet = null;
            //Open the destination WorkBook
            destWorkbook = excelApplicationClass.Workbooks.Open("D:\\Book1.xls", false, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value);
            //Open the source WorkBook
            curWorkBook = excelApplicationClass.Workbooks.Open("D:\\B.xls", false, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value);
            //Open the WorkSheet
            workSheet = (Excel.Worksheet)curWorkBook.Sheets[1];
            newWorksheet = (Excel.Worksheet)destWorkbook.Worksheets.Add(Missing.Value, Missing.Value, Missing.Value, Missing.Value);

            //Copy from source to destination

            workSheet.Copy(Missing.Value, newWorksheet);
            // Save both workboooks
            destWorkbook.Save();
            curWorkBook.Save();	
        }
	}
    }

